$(document).ready(function(){
	$.wmBox();
});